# Caveman Focus — Account Command Center iPhone v0.3

**Native SwiftUI iPhone project with offline workspace plus opt-in private account broker.** This release preserves the existing CF-0 Mission Control. It does not replace or enable AUTO-08, account automation, external payouts, or HP commands.

## Real functions with NO account server

- Create and open multiple *labeled HTTPS account shortcuts* (for ChatGPT/GitHub/Google/Discord/other). Shortcuts are just web links, never authenticated connections.
- Save, review and discard **local-only** task drafts. A review never submits or runs an action.
- Switch off local workflow reviews and separately switch off the private server's execution gate (when connected).
- Retrieve the latest **public CF-0 continuity snapshot** directly from GitHub; the snapshot is dated source evidence, not real-time device or account status.
- Read existing Mission Control link. Everything above works as native UI without paid API usage or server setup, after actual iPhone installation.

## Optional private account control

The Python server provides secured login, GitHub/Google OAuth (each provider requires your own OAuth app registration), read-only account inspection, GitHub issue proposal/approval, events, and optional paid OpenAI developer API planning. The server is **not** shipped as an iPhone background process; it must run behind HTTPS on hardware you control. Consumer ChatGPT account session takeover and other-account conversation control are NOT supported by a general OAuth integration. Do not upload account passwords/tokens to GitHub or this chat.

## Actual iPhone installation routes

### A) Mac + iPhone (free personal-team development signing)

1. Install Xcode on a Mac and sign in with your own Apple Account in Xcode Settings -> Accounts.
2. Run `python3 tools/make_icons.py` once to generate the image assets in a text-only GitHub checkout. (The downloaded ZIP already includes the PNG icons.)
3. Open `NativeApp/AccountCommandCenter.xcodeproj`; choose the `AccountCommandCenter` target -> **Signing & Capabilities** and select your Personal Team. Set a unique bundle ID if Xcode requests it.
4. Connect your iPhone, enable **Developer Mode** if prompted, select the device and click **Run**. Xcode builds, signs, and installs the native app.
5. Apple's free personal-team provisioning has time/device restrictions including 7-day profile expiry. Keep credentials on your Mac.

### B) Windows computer + iPhone (no Mac; unsigned CI build + AltStore)

1. In the CF-0 GitHub feature branch, open Actions -> **Account Command Center - native iOS compile and unsigned IPA** and verify the macOS build has **succeeded**. Download its artifact `AccountCommandCenter-unsigned-IPA-requires-signing` and extract `AccountCommandCenter-UNSIGNED.ipa` on Windows.
2. Follow **AltStore's official Windows setup** at https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows to install AltServer/AltStore onto your own iPhone. This uses your own Apple account locally and may require Apple iTunes/iCloud drivers, USB, device trust and Developer Mode.
3. Import the `.ipa` into AltStore and let it sign/install it. **The IPA is unsigned until this step.** An unsigned build itself cannot be tapped to install in Files/Safari.
4. Keep AltServer available for signing refreshes as described by the AltStore documentation. This path is a proposed device installation path until tested on your phone; sideloaders may reject or fail to sign certain binaries.

If there is no successful GitHub Actions macOS build artifact, route B is **not yet available**. Neither path can be performed by a Linux chat container alone. TestFlight and App Store distribution require the relevant Apple developer enrollment and certificates.

## Security and evidence

Only user-approved account connections are real. Username/URL bookmarks are not OAuth connections; local drafts are not posted issues. The native app stores no third-party passwords or OAuth tokens. The backend uses encrypted server-side token storage, session cookies, CSRF checks, approval queue, and fail-closed action allowlisting; do not expose the server on the public internet without configured HTTPS, backups, and your own provider OAuth apps.

**Continuity:** UCC-001; parent CF-0 / Mission Control; separate child CF-ACC-iOS-001, related AUTO-08 but does not alter it. Source is public-safe, no private account exports. Prior v0.2 ZIP retained for rollback. Complete Xcode build and signed iPhone installation remain distinct acceptance gates.

**Validation available from Linux:** `swiftc -frontend -parse NativeApp/AccountCommandCenter/*.swift`; `plutil -lint NativeApp/AccountCommandCenter.xcodeproj/project.pbxproj`; `cd Backend && python -m pytest -q tests/test_server.py`. Only Apple Xcode can confirm compilation and the signed-device run.
