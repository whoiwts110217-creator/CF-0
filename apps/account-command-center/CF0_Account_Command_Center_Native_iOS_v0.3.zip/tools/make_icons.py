#!/usr/bin/env python3
"""Reproducible zero-dependency PNG icons for native iOS and backend PWA.

Run once before opening/building from a text-only source checkout.
No third-party packages or network access required.
"""
from pathlib import Path
import struct
import zlib

BASE = Path(__file__).resolve().parent.parent
FONT = {
    "A": ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
    "C": ["01111", "10000", "10000", "10000", "10000", "10000", "01111"],
    "0": ["01110", "10001", "10011", "10101", "11001", "10001", "01110"],
}


def draw(size):
    pixels = bytearray(size * size * 3)
    navy = (7, 22, 39)
    panel = (16, 49, 74)
    cyan = (114, 215, 248)
    outline = (43, 140, 185)
    center = (size - 1) / 2
    for y in range(size):
        for x in range(size):
            r = ((x - center) ** 2 + (y - center) ** 2) ** 0.5
            # Rounded square background with two clean orbit rings.
            edge = size * 0.43
            dx = max(abs(x - center) - edge, 0)
            dy = max(abs(y - center) - edge, 0)
            inside = dx * dx + dy * dy <= (size * 0.10) ** 2
            if not inside:
                col = navy
            elif size * .34 < r < size * .355 or size * .245 < r < size * .25:
                col = outline
            else:
                col = panel
            i = (y * size + x) * 3
            pixels[i:i + 3] = bytes(col)
    # Three readable block glyphs, center-aligned.
    height = int(size * .2)
    unit = max(1, height // 7)
    letters = "AC0"
    total_cells = 5 * 3 + 2 * 2
    x0 = (size - total_cells * unit) // 2
    y0 = (size - 7 * unit) // 2
    for k, char in enumerate(letters):
        for row, bits in enumerate(FONT[char]):
            for col, on in enumerate(bits):
                if on == "1":
                    sx = x0 + (k * 7 + col) * unit
                    sy = y0 + row * unit
                    for yy in range(sy, min(sy + unit, size)):
                        start = (yy * size + sx) * 3
                        pixels[start:start + min(unit, size - sx) * 3] = bytes(cyan) * min(unit, size - sx)
    return pixels


def png(size):
    px = draw(size)
    raw = bytearray()
    width = size * 3
    for y in range(size):
        raw.append(0)
        raw += px[y * width:(y + 1) * width]

    def chunk(typ, data):
        return struct.pack(">I", len(data)) + typ + data + struct.pack(">I", zlib.crc32(typ + data) & 0xffffffff)

    return (b"\x89PNG\r\n\x1a\n" +
            chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b""))


def main():
    images = {
        BASE / "NativeApp/AccountCommandCenter/Assets.xcassets/AppIcon.appiconset/AppIcon.png": 1024,
        BASE / "Backend/web/icon-192.png": 192,
        BASE / "Backend/web/icon-512.png": 512,
    }
    for path, size in images.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(png(size))
        print(f"Created {path.relative_to(BASE)} ({size}x{size})")


if __name__ == "__main__":
    main()
