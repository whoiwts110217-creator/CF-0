import SwiftUI

@main
struct AccountCommandCenterApp: App {
    @StateObject private var store = AccountStore()
    @StateObject private var local = LocalHub()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environmentObject(local)
                .preferredColorScheme(.dark)
        }
    }
}
