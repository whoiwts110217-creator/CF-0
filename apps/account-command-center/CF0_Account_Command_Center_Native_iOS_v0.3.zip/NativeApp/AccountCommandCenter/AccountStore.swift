import Foundation
import SwiftUI

struct LinkedAccount: Decodable, Identifiable {
    let id: String
    let provider: String
    let display_name: String
    let email: String
    let scope: String
}

struct WorkTask: Decodable, Identifiable {
    let id: String
    let kind: String
    let account_id: String
    let title: String
    let status: String
    let created_at: Int
    let result: String?
}

struct ActivityEvent: Decodable, Identifiable {
    let id: Int
    let happened_at: Int
    let kind: String
    let description: String
}

struct Bootstrap: Decodable {
    let csrf: String
    let accounts: [LinkedAccount]
    let tasks: [WorkTask]
    let events: [ActivityEvent]
    let paused: Bool
}

struct APIStatus: Decodable {
    let ok: Bool
    let providers: ProviderSupport
}

struct ProviderSupport: Decodable {
    let github: Bool
    let google: Bool
    let openai_api: Bool
}

struct PlanOutput: Decodable {
    let plan: String
    let executed: Bool
}

struct AccountInspection: Decodable {
    let kind: String
    let items: [InspectionItem]
}

struct InspectionItem: Decodable, Identifiable {
    let name: String
    let html_url: String?
    let type: String?
    var id: String { name }
}

struct APIError: Decodable {
    let detail: String?
}

enum AccountCommandError: LocalizedError {
    case configuration, notSignedIn, invalidResponse, server(String)
    var errorDescription: String? {
        switch self {
        case .configuration: return "Set a private HTTPS server address in Settings. The app is not connected yet."
        case .notSignedIn: return "Sign in to your own private server first."
        case .invalidResponse: return "The server returned an unexpected response."
        case .server(let text): return text
        }
    }
}

@MainActor
final class AccountStore: ObservableObject {
    @Published var serverAddress: String = UserDefaults.standard.string(forKey: "ACCServerAddress") ?? ""
    @Published var connected = false
    @Published var signedIn = false
    @Published var busy = false
    @Published var paused = false
    @Published var accounts: [LinkedAccount] = []
    @Published var tasks: [WorkTask] = []
    @Published var events: [ActivityEvent] = []
    @Published var support = ProviderSupport(github: false, google: false, openai_api: false)
    @Published var notice: String?
    @Published var latestPlan = ""
    @Published var latestInspection = ""
    private var csrf = ""

    private let decoder = JSONDecoder()
    private let encoder = JSONEncoder()
    // URLSession keeps the password out of UserDefaults. The server manages HttpOnly cookies.
    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.httpCookieStorage = .shared
        config.httpShouldSetCookies = true
        return URLSession(configuration: config)
    }()

    var origin: URL? {
        guard let u = URL(string: serverAddress.trimmingCharacters(in: .whitespacesAndNewlines)),
              u.scheme == "https", u.host != nil, u.user == nil, u.password == nil,
              u.query == nil, u.fragment == nil else { return nil }
        return u
    }

    func updateServer() {
        serverAddress = serverAddress.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        UserDefaults.standard.set(serverAddress, forKey: "ACCServerAddress")
        connected = false; signedIn = false; csrf = ""
        accounts = []; tasks = []; events = []; latestPlan = ""; latestInspection = ""
        notice = "Server address saved. Connect only to a private HTTPS server you control."
    }

    private func request<T: Decodable>(_ route: String, method: String = "GET", body: Data? = nil, authenticatedWrite: Bool = false) async throws -> T {
        guard let origin else { throw AccountCommandError.configuration }
        guard let url = URL(string: route, relativeTo: origin)?.absoluteURL else { throw AccountCommandError.configuration }
        var r = URLRequest(url: url)
        r.httpMethod = method
        r.timeoutInterval = 25
        r.setValue("application/json", forHTTPHeaderField: "Accept")
        if body != nil { r.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        if authenticatedWrite {
            guard signedIn, !csrf.isEmpty else { throw AccountCommandError.notSignedIn }
            r.setValue(csrf, forHTTPHeaderField: "x-csrf-token")
        }
        r.httpBody = body
        let (data, response) = try await session.data(for: r)
        guard let http = response as? HTTPURLResponse else { throw AccountCommandError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            let details = try? decoder.decode(APIError.self, from: data)
            throw AccountCommandError.server(details?.detail ?? "Server HTTP \(http.statusCode)")
        }
        return try decoder.decode(T.self, from: data)
    }

    private func run(_ work: () async throws -> Void) async {
        busy = true
        defer { busy = false }
        do { try await work() } catch { notice = error.localizedDescription }
    }

    func probe() async {
        await run {
            let s: APIStatus = try await request("/api/status")
            connected = s.ok; support = s.providers
            notice = "Private server responded. Sign in to access your authorized accounts."
        }
    }

    func login(password: String) async {
        await run {
            let body = try encoder.encode(["password": password])
            let reply: LoginReply = try await request("/api/login", method: "POST", body: body)
            guard reply.ok else { throw AccountCommandError.invalidResponse }
            csrf = reply.csrf; signedIn = true
            try await refreshImpl()
            notice = "Authenticated to your private server."
        }
    }

    func refresh() async { await run { try await refreshImpl() } }

    private func refreshImpl() async throws {
        let s: Bootstrap = try await request("/api/bootstrap")
        csrf = s.csrf; signedIn = true; connected = true
        accounts = s.accounts; tasks = s.tasks; events = s.events; paused = s.paused
    }

    func setPaused(_ value: Bool) async {
        await run {
            let body = try encoder.encode(["paused": value])
            let _: ControlReply = try await request("/api/control", method: "POST", body: body, authenticatedWrite: true)
            try await refreshImpl()
            notice = value ? "This controller's actions stopped. Other systems remain unaffected." : "This controller can execute separately approved actions again."
        }
    }

    func proposeGithubIssue(accountID: String, owner: String, repository: String, title: String, body: String) async {
        await run {
            let value = NewTask(kind: "github_create_issue", account_id: accountID,
                                payload: .init(owner: owner, repo: repository, title: title, body: body))
            let _: TaskAcknowledgement = try await request("/api/tasks", method: "POST", body: encoder.encode(value), authenticatedWrite: true)
            try await refreshImpl()
            notice = "Proposal created. No issue was posted. Approve it separately in Tasks."
        }
    }

    func decide(_ task: WorkTask, approve: Bool) async {
        await run {
            let route = "/api/tasks/\(task.id)/" + (approve ? "execute" : "reject")
            let _: DecisionReply = try await request(route, method: "POST", authenticatedWrite: true)
            try await refreshImpl()
            notice = approve ? "Execution submitted. Check the task receipt for the provider-confirmed outcome." : "Proposal rejected."
        }
    }

    func inspect(_ account: LinkedAccount) async {
        await run {
            let result: AccountInspection = try await request("/api/accounts/\(account.id)/inspect")
            latestInspection = result.items.isEmpty ? "No items returned." : result.items.map { "• \($0.name)" }.joined(separator: "\n")
            notice = "Read-only inspection returned from \(account.display_name)."
        }
    }

    func unlink(_ account: LinkedAccount) async {
        await run {
            let _: DecisionReply = try await request("/api/accounts/\(account.id)", method: "DELETE", authenticatedWrite: true)
            try await refreshImpl()
            notice = "Connection removed from this server. Revoke the app in \(account.provider)'s account settings too."
        }
    }

    func plan(goal: String) async {
        await run {
            let reply: PlanOutput = try await request("/api/ai/plan", method: "POST", body: encoder.encode(["goal": goal]), authenticatedWrite: true)
            latestPlan = reply.plan
            notice = reply.executed ? "Unexpected execution flag; inspect the server." : "Plan generated. No actions executed."
        }
    }

    func logout() async {
        await run {
            let _: DecisionReply = try await request("/api/logout", method: "POST", authenticatedWrite: true)
            signedIn = false; csrf = ""; accounts = []; tasks = []; events = []
            notice = "Signed out of this controller."
        }
    }
}

private struct LoginReply: Decodable { let ok: Bool; let csrf: String }
private struct ControlReply: Decodable { let paused: Bool }
private struct DecisionReply: Decodable { let ok: Bool?; let status: String?; let note: String?; let url: String? }
private struct TaskAcknowledgement: Decodable { let id: String; let status: String }
private struct NewTask: Encodable {
    let kind: String
    let account_id: String
    let payload: GitHubIssue
}
private struct GitHubIssue: Encodable {
    let owner: String
    let repo: String
    let title: String
    let body: String
}
