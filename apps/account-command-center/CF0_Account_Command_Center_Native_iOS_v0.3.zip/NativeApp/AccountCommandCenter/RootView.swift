import SwiftUI

private let cyan = Color(red: 0.47, green: 0.83, blue: 1.0)
private let backdrop = Color(red: 0.035, green: 0.055, blue: 0.095)
private let pane = Color(red: 0.075, green: 0.115, blue: 0.17)

struct RootView: View {
    @EnvironmentObject private var store: AccountStore
    @EnvironmentObject private var local: LocalHub
    @State private var tab = 0
    @State private var showNotice = false

    var body: some View {
        TabView(selection: $tab) {
            DashboardView(changeTab: { tab = $0 })
                .tabItem { Label("Control", systemImage: "square.grid.2x2") }.tag(0)
            AccountsView()
                .tabItem { Label("Accounts", systemImage: "person.2.badge.key") }.tag(1)
            TasksView()
                .tabItem { Label("Tasks", systemImage: "checklist") }.tag(2)
            ActivityView()
                .tabItem { Label("Activity", systemImage: "clock.arrow.circlepath") }.tag(3)
            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }.tag(4)
        }
        .tint(cyan)
        .background(backdrop)
        .onChange(of: store.notice) { _, newValue in showNotice = newValue != nil }
        .onChange(of: local.message) { _, newValue in
            if let newValue { store.notice = newValue; local.message = nil }
        }
        .alert("Account Command Center", isPresented: $showNotice) {
            Button("OK") { store.notice = nil }
        } message: { Text(store.notice ?? "") }
    }
}

private struct Frame<Content: View>: View {
    let title: String
    let icon: String
    let content: Content
    init(title: String, icon: String, @ViewBuilder content: () -> Content) {
        self.title = title; self.icon = icon; self.content = content()
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 15) { content }
                    .padding(18)
                    .frame(maxWidth: 700)
                    .frame(maxWidth: .infinity)
            }
            .background(backdrop.ignoresSafeArea())
            .navigationTitle(title)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Image(systemName: icon).foregroundStyle(cyan)
                }
            }
        }
    }
}

private struct Surface<Content: View>: View {
    let header: String
    let caption: String
    let content: Content
    init(header: String, caption: String, @ViewBuilder content: () -> Content) {
        self.header = header; self.caption = caption; self.content = content()
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 11) {
            Text(header).font(.headline).foregroundStyle(.white)
            Text(caption).font(.caption).foregroundStyle(.white.opacity(0.65))
            content
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(pane, in: RoundedRectangle(cornerRadius: 17))
        .overlay(RoundedRectangle(cornerRadius: 17).strokeBorder(cyan.opacity(0.15)))
    }
}

private struct StatusLine: View {
    let title: String
    let value: String
    let accent: Color
    var body: some View {
        HStack {
            Text(title).foregroundStyle(.white.opacity(0.7))
            Spacer()
            Text(value).foregroundStyle(accent).fontWeight(.semibold)
        }.font(.subheadline)
    }
}

private struct HelpNote: View {
    let text: String
    @State private var showHelp = false
    var body: some View {
        Button { showHelp.toggle() } label: {
            Label("What does this mean?", systemImage: "questionmark.circle")
                .font(.caption).foregroundStyle(cyan)
        }
        .alert("Explanation", isPresented: $showHelp) {
            Button("OK", role: .cancel) { }
        } message: { Text(text) }
    }
}

struct DashboardView: View {
    @EnvironmentObject private var store: AccountStore
    @EnvironmentObject private var local: LocalHub
    let changeTab: (Int) -> Void
    var body: some View {
        Frame(title: "Command Center", icon: "bolt.shield") {
            HStack(spacing: 12) {
                Image(systemName: "bolt.shield.fill")
                    .font(.system(size: 32, weight: .medium)).foregroundStyle(cyan)
                VStack(alignment: .leading, spacing: 4) {
                    Text("ONE CONTROLLER").tracking(2).font(.caption2).foregroundStyle(cyan)
                    Text("Your accounts. Your rules.").font(.headline)
                }
            }.padding(.vertical, 9)

            Surface(header: "Works without a private server", caption: "Read-only Caveman Focus status and your saved local workspace shortcuts are accessible directly from this iPhone.") {
                StatusLine(title: "Local shortcuts", value: "\(local.shortcuts.count)", accent: cyan)
                StatusLine(title: "Local drafts", value: "\(local.drafts.filter { $0.state == "local_draft" }.count)", accent: cyan)
                StatusLine(title: "Local review gate", value: local.localStop ? "STOPPED" : "AVAILABLE", accent: local.localStop ? .orange : .green)
                Text(local.publicSummary).font(.footnote).foregroundStyle(.white.opacity(0.9))
                Text(local.publicEvidence).font(.caption2).foregroundStyle(.white.opacity(0.6))
                Button(local.checkingPublic ? "Checking…" : "Refresh public CF-0 status") {
                    Task { await local.refreshPublic() }
                }
                .buttonStyle(.bordered).disabled(local.checkingPublic)
                HStack {
                    Button("Accounts and shortcuts") { changeTab(1) }.buttonStyle(.bordered)
                    Button("Local task drafts") { changeTab(2) }.buttonStyle(.bordered)
                }
                HelpNote(text: "These local features work without account authorization. Refresh only reads a public GitHub file; it does not control your HP, ChatGPT, or provider services.")
            }

            Surface(header: "Connection health", caption: "Live results come from your private account-control server, not public GitHub.") {
                StatusLine(title: "Server", value: store.connected ? "REACHABLE" : "NOT CONNECTED", accent: store.connected ? .green : .orange)
                StatusLine(title: "Owner session", value: store.signedIn ? "SIGNED IN" : "SIGNED OUT", accent: store.signedIn ? .green : .orange)
                StatusLine(title: "Linked accounts", value: "\(store.accounts.count)", accent: cyan)
                StatusLine(title: "This app's executor", value: store.paused ? "STOPPED" : "AVAILABLE", accent: store.paused ? .orange : cyan)
                HelpNote(text: "Available means that the private server is accepting approved actions. It does not mean ChatGPT, Windows, GitHub Actions, or other external systems are running automatically.")
                HStack {
                    Button("Settings") { changeTab(4) }.buttonStyle(.bordered)
                    Button("Refresh") { Task { await store.refresh() } }
                        .buttonStyle(.borderedProminent).tint(cyan).foregroundStyle(.black)
                        .disabled(!store.signedIn || store.busy)
                }
            }

            Surface(header: "Execution master switch", caption: "Stops future action requests made through this server. It cannot stop already-running external jobs.") {
                Button {
                    Task { await store.setPaused(!store.paused) }
                } label: {
                    Label(store.paused ? "Resume this controller" : "STOP this controller", systemImage: store.paused ? "play.circle" : "hand.raised.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(store.paused ? .green : .red)
                .disabled(!store.signedIn || store.busy)
                HelpNote(text: "Emergency Stop is scoped to Account Command Center's task-execution endpoint. It does NOT shut off scheduled CF-0 workers, ChatGPT conversations, provider apps, or the HP relay.")
            }

            Surface(header: "Connected systems", caption: "Provider features appear only when configured on the server.") {
                StatusLine(title: "GitHub", value: store.support.github ? "OAUTH CONFIGURED" : "SETUP REQUIRED", accent: store.support.github ? .green : .orange)
                StatusLine(title: "Google", value: store.support.google ? "OAUTH CONFIGURED" : "SETUP REQUIRED", accent: store.support.google ? .green : .orange)
                StatusLine(title: "OpenAI planning API", value: store.support.openai_api ? "CONFIGURED" : "OPTIONAL", accent: cyan)
                StatusLine(title: "Consumer ChatGPT accounts", value: "NOT LINKED", accent: .orange)
                Button("Manage accounts") { changeTab(1) }.buttonStyle(.bordered)
            }

            Surface(header: "Caveman Focus continuity", caption: "Existing Mission Control is preserved as a separate read-only system.") {
                Link(destination: URL(string: "https://whoiwts110217-creator.github.io/CF-0/mission-control/")!) {
                    Label("Open existing Mission Control", systemImage: "arrow.up.right.square")
                }.foregroundStyle(cyan)
                Text("The AUTO-08 ChatGPT conversation runner is not silently enabled by this new app.")
                    .font(.caption).foregroundStyle(.white.opacity(0.65))
            }
        }
    }
}

struct AccountsView: View {
    @EnvironmentObject private var store: AccountStore
    @EnvironmentObject private var local: LocalHub
    @State private var linkName = ""
    @State private var linkURL = ""
    @State private var linkCategory = "ChatGPT"
    @State private var selectedForRemoval: LinkedAccount?
    @State private var askRemoval = false

    var body: some View {
        Frame(title: "Accounts", icon: "person.crop.circle.badge.checkmark") {
            Surface(header: "Authorization", caption: "Connect provider accounts from the secure browser page. This native app reads the same private server after you return.") {
                Text("1. Open the account portal in Safari.  2. Sign in to that private portal.  3. Select GitHub or Google there.  4. Return here and tap Refresh.")
                    .font(.subheadline).foregroundStyle(.white.opacity(0.85))
                if let url = store.origin, store.connected {
                    Link(destination: url) {
                        Label("Open private account portal", systemImage: "safari")
                    }.foregroundStyle(cyan)
                }
                HelpNote(text: "Provider OAuth happens through Safari to avoid collecting passwords or bypassing provider login restrictions. This means you may sign in to the controller separately in Safari. ChatGPT consumer accounts are NOT supported by OAuth here.")
                Button("Refresh accounts") { Task { await store.refresh() } }
                    .buttonStyle(.bordered).disabled(!store.signedIn || store.busy)
            }

            Surface(header: "Account shortcuts — on this iPhone", caption: "Save different ChatGPT, GitHub, Google, Discord or other login URLs. A shortcut opens the official website; it does not read or control that account.") {
                TextField("Label, e.g. Second GPT account", text: $linkName).textFieldStyle(.roundedBorder)
                TextField("https://…", text: $linkURL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    .keyboardType(.URL).textFieldStyle(.roundedBorder)
                Picker("Category", selection: $linkCategory) {
                    ForEach(["ChatGPT", "GitHub", "Google", "Discord", "Other"], id: \.self) { value in Text(value).tag(value) }
                }.tint(cyan)
                Button("Save shortcut") {
                    local.addShortcut(label: linkName, address: linkURL, category: linkCategory)
                    linkName = ""; linkURL = ""
                }.buttonStyle(.borderedProminent).tint(cyan).foregroundStyle(.black)
                ForEach(local.shortcuts) { shortcut in
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(shortcut.label).fontWeight(.semibold)
                            Text(shortcut.category + " · SHORTCUT ONLY").font(.caption2).foregroundStyle(.white.opacity(0.65))
                        }
                        Spacer()
                        if let url = LocalHub.safeURL(shortcut.address) {
                            Link(destination: url) { Image(systemName: "arrow.up.right.square") }.foregroundStyle(cyan)
                        }
                        Button(role: .destructive) { local.removeShortcut(shortcut.id) } label: {
                            Image(systemName: "trash")
                        }
                        .foregroundStyle(.orange)
                    }
                    Divider().overlay(cyan.opacity(0.13))
                }
            }

            if store.accounts.isEmpty {
                Surface(header: "No authorized accounts", caption: "A saved name or URL is not a real account connection.") {
                    Label("Provider authorization required", systemImage: "lock.shield")
                        .foregroundStyle(.orange)
                }
            }

            ForEach(store.accounts) { account in
                Surface(header: account.display_name, caption: "\(account.provider.uppercased()) · \(account.email)") {
                    Text("Granted scope: \(account.scope.isEmpty ? "Provider default" : account.scope)")
                        .font(.caption2).foregroundStyle(.white.opacity(0.62))
                        .lineLimit(3)
                    HStack {
                        Button("Inspect read-only") { Task { await store.inspect(account) } }
                            .buttonStyle(.bordered).disabled(store.busy)
                        Spacer()
                        Button("Unlink", role: .destructive) {
                            selectedForRemoval = account; askRemoval = true
                        }.buttonStyle(.bordered)
                    }
                }
            }
            if !store.latestInspection.isEmpty {
                Surface(header: "Read-only result", caption: "Recent selected account inspection") {
                    Text(store.latestInspection).font(.footnote).textSelection(.enabled)
                }
            }
        }
        .confirmationDialog("Unlink this provider account?", isPresented: $askRemoval) {
            if let a = selectedForRemoval {
                Button("Unlink \(a.display_name)", role: .destructive) { Task { await store.unlink(a) } }
            }
        } message: { Text("This deletes the stored connection locally. Revoke provider authorization separately in its security settings.") }
    }
}

struct TasksView: View {
    @EnvironmentObject private var store: AccountStore
    @EnvironmentObject private var local: LocalHub
    @State private var localTitle = ""
    @State private var localDetails = ""
    @State private var accountID = ""
    @State private var owner = ""
    @State private var repository = ""
    @State private var issueTitle = ""
    @State private var issueBody = ""
    @State private var targetTask: WorkTask?
    @State private var showingReview = false
    @State private var goal = ""

    private var githubAccounts: [LinkedAccount] { store.accounts.filter { $0.provider == "github" } }
    var body: some View {
        Frame(title: "Tasks", icon: "checkmark.seal") {
            Surface(header: "Local task queue", caption: "Works on the iPhone without a server. These are private notes, never external actions.") {
                TextField("Task title", text: $localTitle).textFieldStyle(.roundedBorder)
                TextField("Details and evidence", text: $localDetails, axis: .vertical)
                    .lineLimit(2...5).textFieldStyle(.roundedBorder)
                Button("Save local proposal") {
                    local.addDraft(title: localTitle, details: localDetails)
                    localTitle = ""; localDetails = ""
                }.buttonStyle(.borderedProminent).tint(cyan).foregroundStyle(.black)
                    .disabled(local.localStop || localTitle.count < 3)
                ForEach(local.drafts) { draft in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(draft.title).fontWeight(.semibold)
                        Text(draft.details).font(.caption).foregroundStyle(.white.opacity(0.72))
                        StatusLine(title: "Local state", value: draft.state.uppercased().replacingOccurrences(of: "_", with: " "), accent: cyan)
                        if draft.state == "local_draft" {
                            HStack {
                                Button("Mark reviewed") { local.reviewDraft(draft.id, accept: true) }.buttonStyle(.bordered)
                                Button("Discard") { local.reviewDraft(draft.id, accept: false) }.buttonStyle(.bordered)
                            }.disabled(local.localStop)
                        }
                    }
                    Divider().overlay(cyan.opacity(0.13))
                }
                HelpNote(text: "Reviewed only means you checked this proposal. It does not submit anything to GitHub, Gmail, ChatGPT or another account.")
            }

            Surface(header: "Draft a GitHub issue", caption: "Creates a private proposal first. Posting happens only after a separate approval.") {
                Picker("Identity", selection: $accountID) {
                    Text("Select account").tag("")
                    ForEach(githubAccounts) { account in Text(account.display_name).tag(account.id) }
                }.tint(cyan)
                TextField("Repository owner", text: $owner).textInputAutocapitalization(.never).autocorrectionDisabled()
                    .textFieldStyle(.roundedBorder)
                TextField("Repository name", text: $repository).textInputAutocapitalization(.never).autocorrectionDisabled()
                    .textFieldStyle(.roundedBorder)
                TextField("Issue title", text: $issueTitle).textFieldStyle(.roundedBorder)
                TextField("Description", text: $issueBody, axis: .vertical).lineLimit(2...5).textFieldStyle(.roundedBorder)
                Button("Queue for approval") {
                    Task { await store.proposeGithubIssue(accountID: accountID, owner: owner, repository: repository, title: issueTitle, body: issueBody) }
                }
                .buttonStyle(.borderedProminent).tint(cyan).foregroundStyle(.black)
                .disabled(!store.signedIn || store.busy || accountID.isEmpty || owner.isEmpty || repository.isEmpty || issueTitle.isEmpty)
                HelpNote(text: "This form can only create GitHub issues through the private server. It cannot arbitrarily control your browser, send email, make purchases, or run commands on your HP.")
            }

            Surface(header: "GPT planning assistant", caption: "Optional developer API feature, not a connection to your personal ChatGPT history.") {
                TextField("What do you want organized?", text: $goal, axis: .vertical)
                    .lineLimit(2...4).textFieldStyle(.roundedBorder)
                Button("Generate a plan (no execution)") { Task { await store.plan(goal: goal) } }
                    .buttonStyle(.bordered)
                    .disabled(!store.signedIn || !store.support.openai_api || goal.count < 3 || store.busy)
                if !store.latestPlan.isEmpty {
                    Text(store.latestPlan).font(.footnote).textSelection(.enabled)
                }
                HelpNote(text: "OpenAI's developer API is separately configured and may incur API charges. A ChatGPT Plus or other subscription does not provide an account-control token.")
            }

            Surface(header: "Approval queue", caption: "Tasks never execute merely because they appear in this queue.") {
                if store.tasks.isEmpty { Text("No recorded tasks.").foregroundStyle(.white.opacity(0.7)) }
                ForEach(store.tasks) { task in
                    VStack(alignment: .leading, spacing: 7) {
                        Text(task.title).font(.subheadline).fontWeight(.semibold)
                        StatusLine(title: "State", value: task.status.uppercased().replacingOccurrences(of: "_", with: " "), accent: task.status == "completed" ? .green : (task.status == "outcome_unknown" ? .orange : cyan))
                        if task.status == "pending_approval" {
                            Button("Review action") { targetTask = task; showingReview = true }
                                .buttonStyle(.bordered).disabled(store.busy)
                        }
                        if let result = task.result, !result.isEmpty { Text(result).font(.caption).textSelection(.enabled) }
                    }
                    Divider().overlay(cyan.opacity(0.17))
                }
            }
        }
        .confirmationDialog("Approve external provider action?", isPresented: $showingReview) {
            if let t = targetTask {
                Button("Execute once") { Task { await store.decide(t, approve: true) } }
                Button("Reject", role: .destructive) { Task { await store.decide(t, approve: false) } }
            }
        } message: {
            Text("This sends the specific pending GitHub issue task to the server. Verify the repository and issue title before approving; unknown outcomes are never retried automatically.")
        }
    }
}

struct ActivityView: View {
    @EnvironmentObject private var store: AccountStore
    var body: some View {
        Frame(title: "Activity", icon: "list.bullet.rectangle") {
            Surface(header: "Evidence ledger", caption: "These are server-side action records, not a claim of ongoing external automation.") {
                Button("Refresh ledger") { Task { await store.refresh() } }
                    .buttonStyle(.bordered).disabled(!store.signedIn || store.busy)
                if store.events.isEmpty { Text("No server events available.").foregroundStyle(.white.opacity(0.7)) }
                ForEach(store.events) { event in
                    VStack(alignment: .leading, spacing: 3) {
                        Text(event.kind.uppercased()).font(.caption2).fontWeight(.bold).foregroundStyle(cyan)
                        Text(event.description).font(.subheadline)
                        Text(Date(timeIntervalSince1970: TimeInterval(event.happened_at)), style: .date)
                            .font(.caption2).foregroundStyle(.white.opacity(0.55))
                    }
                    Divider().overlay(cyan.opacity(0.16))
                }
            }
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject private var store: AccountStore
    @EnvironmentObject private var local: LocalHub
    @State private var password = ""
    var body: some View {
        Frame(title: "Settings", icon: "lock.shield") {
            Surface(header: "Local emergency stop", caption: "This stops the on-device draft-review workflow only; it cannot stop remote services.") {
                Button {
                    local.setLocalStop(!local.localStop)
                } label: {
                    Label(local.localStop ? "Resume local workflow" : "STOP local workflow", systemImage: local.localStop ? "play.fill" : "hand.raised.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent).tint(local.localStop ? .green : .red)
            }

            Surface(header: "Private server", caption: "Required for actual account connections. Address must begin with https://.") {
                TextField("https://your-private-domain.example", text: $store.serverAddress)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .keyboardType(.URL).textFieldStyle(.roundedBorder)
                Button("Save server address") { store.updateServer() }
                    .buttonStyle(.bordered)
                    .disabled(store.origin == nil)
                Button("Check server") { Task { await store.probe() } }
                    .buttonStyle(.borderedProminent).tint(cyan).foregroundStyle(.black)
                    .disabled(store.origin == nil || store.busy)
            }

            Surface(header: "Owner session", caption: "The password is sent to your private HTTPS server and is never saved in the app.") {
                if !store.signedIn {
                    SecureField("Server owner password", text: $password).textFieldStyle(.roundedBorder)
                    Button("Sign in") {
                        let p = password; password = ""
                        Task { await store.login(password: p) }
                    }
                    .buttonStyle(.borderedProminent).tint(cyan).foregroundStyle(.black)
                    .disabled(!store.connected || password.isEmpty || store.busy)
                } else {
                    Label("Signed into private server", systemImage: "checkmark.shield").foregroundStyle(.green)
                    Button("Sign out") { Task { await store.logout() } }.buttonStyle(.bordered)
                }
            }

            Surface(header: "What this app cannot do yet", caption: "Accurate boundaries are part of account safety.") {
                Text("• No automatic access to consumer ChatGPT accounts or archived conversations.\n• No unattended background runner on an iPhone.\n• No cash transfer, account takeover, browser automation, or unrestricted PC control.\n• No account has been linked until the private server is hosted and provider OAuth is configured.\n• No App Store or TestFlight distribution has been performed.")
                    .font(.footnote).foregroundStyle(.white.opacity(0.8))
                HelpNote(text: "The new iPhone interface is native SwiftUI. The private Python account broker remains a separate computer/server service. It is not bundled into or executed by the iOS app.")
            }
        }
    }
}
