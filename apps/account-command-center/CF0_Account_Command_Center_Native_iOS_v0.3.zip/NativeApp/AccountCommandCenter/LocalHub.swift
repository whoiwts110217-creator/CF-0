import Foundation
import SwiftUI

// Local-only workspace conveniences. These are links and drafts, never provider authorization.
struct LocalShortcut: Identifiable, Codable {
    var id: UUID = UUID()
    var label: String
    var address: String
    var category: String
}

struct LocalDraft: Identifiable, Codable {
    var id: UUID = UUID()
    var title: String
    var details: String
    var state: String = "local_draft"
    var createdAt: Date = Date()
}

private struct PublicContinuityResponse: Decodable {
    struct CF200: Decodable { let verified: Int; let target: Int }
    let as_of_date_et: String
    let cf200: CF200
}

@MainActor
final class LocalHub: ObservableObject {
    @Published private(set) var shortcuts: [LocalShortcut] = []
    @Published private(set) var drafts: [LocalDraft] = []
    @Published private(set) var localStop = false
    @Published private(set) var publicSummary = "Not checked"
    @Published private(set) var publicEvidence = "Public project source only — no device, HP or account control verified"
    @Published private(set) var publicCheckedAt: Date?
    @Published private(set) var checkingPublic = false
    @Published var message: String?

    init() {
        if let data = UserDefaults.standard.data(forKey: "acc.local.shortcuts.v1"),
           let items = try? JSONDecoder().decode([LocalShortcut].self, from: data) { shortcuts = items }
        if let data = UserDefaults.standard.data(forKey: "acc.local.drafts.v1"),
           let items = try? JSONDecoder().decode([LocalDraft].self, from: data) { drafts = items }
        localStop = UserDefaults.standard.bool(forKey: "acc.local.stop.v1")
    }

    private func save() {
        if let data = try? JSONEncoder().encode(shortcuts) { UserDefaults.standard.set(data, forKey: "acc.local.shortcuts.v1") }
        if let data = try? JSONEncoder().encode(drafts) { UserDefaults.standard.set(data, forKey: "acc.local.drafts.v1") }
        UserDefaults.standard.set(localStop, forKey: "acc.local.stop.v1")
    }

    static func safeURL(_ raw: String) -> URL? {
        guard let url = URL(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)),
              url.scheme?.lowercased() == "https", url.host != nil,
              url.user == nil, url.password == nil,
              url.port == nil || (url.port! > 0 && url.port! < 65536) else { return nil }
        return url
    }

    func addShortcut(label: String, address: String, category: String) {
        let name = label.trimmingCharacters(in: .whitespacesAndNewlines)
        guard name.count >= 2, name.count <= 70, let url = Self.safeURL(address), shortcuts.count < 100 else {
            message = "Enter a short label and a valid HTTPS account link. No passwords or tokens."
            return
        }
        shortcuts.append(LocalShortcut(label: name, address: url.absoluteString, category: category))
        save()
        message = "Shortcut saved on this iPhone. It is not an authenticated account connection."
    }

    func removeShortcut(_ id: UUID) {
        shortcuts.removeAll { $0.id == id }
        save()
    }

    func addDraft(title: String, details: String) {
        let cleaned = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !localStop else { message = "Local task reviews are stopped."; return }
        guard cleaned.count >= 3, cleaned.count <= 180, details.count <= 6000 else {
            message = "Title must be 3–180 characters; details must be under 6,000 characters."
            return
        }
        drafts.insert(LocalDraft(title: cleaned, details: details), at: 0)
        save()
        message = "Saved as a local draft. No external account action was performed."
    }

    func reviewDraft(_ id: UUID, accept: Bool) {
        guard !localStop else { message = "Local task reviews are stopped."; return }
        guard let i = drafts.firstIndex(where: { $0.id == id && $0.state == "local_draft" }) else { return }
        drafts[i].state = accept ? "reviewed_only" : "discarded"
        save()
        message = accept ? "Marked reviewed locally. Nothing was sent to a provider." : "Local draft discarded."
    }

    func setLocalStop(_ enabled: Bool) {
        localStop = enabled
        save()
        message = enabled ? "Local reviews stopped. Remote CF-0 systems are unaffected." : "Local reviews resumed. Remote actions still require separate authorization."
    }

    func refreshPublic() async {
        guard !checkingPublic else { return }
        checkingPublic = true
        defer { checkingPublic = false }
        guard let url = URL(string: "https://raw.githubusercontent.com/whoiwts110217-creator/CF-0/main/docs/PUBLIC_CONTINUITY_STATE.json") else { return }
        do {
            var request = URLRequest(url: url)
            request.cachePolicy = .reloadIgnoringLocalCacheData
            request.timeoutInterval = 15
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200, data.count < 100_000 else {
                throw URLError(.badServerResponse)
            }
            let item = try JSONDecoder().decode(PublicContinuityResponse.self, from: data)
            publicSummary = "CF-200: \(item.cf200.verified) / \(item.cf200.target) source-verified · as of \(item.as_of_date_et)"
            publicEvidence = "Read-only public GitHub record. No live account session, unattended HP execution, or financial verification implied."
            publicCheckedAt = Date()
        } catch {
            publicSummary = "Public source unavailable"
            publicEvidence = "No reliable new status. Previous source must not be treated as live."
            message = "Could not refresh CF-0 public status: \(error.localizedDescription)"
        }
    }
}
