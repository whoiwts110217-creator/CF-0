@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
if not exist .env py setup_local.py
py run.py
