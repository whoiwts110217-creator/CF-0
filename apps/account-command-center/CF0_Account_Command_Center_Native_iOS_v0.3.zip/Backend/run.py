"""Run Account Command Center. Default bind: loopback only (not directly reachable from iPhone)."""
import os
from pathlib import Path
from dotenv import load_dotenv
load_dotenv(Path(__file__).resolve().parent / '.env')
import uvicorn
if __name__ == '__main__':
    uvicorn.run('server.app:app', host='127.0.0.1', port=int(os.getenv('PORT','8787')), reload=False)
