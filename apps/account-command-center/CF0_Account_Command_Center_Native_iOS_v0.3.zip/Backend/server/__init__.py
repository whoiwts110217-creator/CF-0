"""Account Command Center server."""
