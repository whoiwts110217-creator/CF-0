"""Account Command Center: local-first persistence, input gates, and token encryption."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlparse
from cryptography.fernet import Fernet, InvalidToken

ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = Path(os.getenv("ACC_DB_PATH", str(ROOT / "private" / "account_control.sqlite3")))
ACCOUNT_ACTIONS = {"github_create_issue"}
ALLOWED_PROVIDERS = {"github", "google"}
GITHUB_REPO = re.compile(r"^[A-Za-z0-9_.-]{1,100}$")


def settings():
    return {
        "password": os.getenv("ACC_ADMIN_PASSWORD", ""),
        "key": os.getenv("ACC_ENCRYPTION_KEY", ""),
        "origin": os.getenv("ACC_BASE_URL", "http://127.0.0.1:8787").rstrip("/"),
        "cookie_secure": os.getenv("ACC_SECURE_COOKIES", "0") == "1",
        "github_client_id": os.getenv("GITHUB_CLIENT_ID", ""),
        "github_client_secret": os.getenv("GITHUB_CLIENT_SECRET", ""),
        "google_client_id": os.getenv("GOOGLE_CLIENT_ID", ""),
        "google_client_secret": os.getenv("GOOGLE_CLIENT_SECRET", ""),
        "openai_api_key": os.getenv("OPENAI_API_KEY", ""),
        "openai_model": os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
    }


def startup_guard(cfg):
    if len(cfg["password"]) < 12:
        raise RuntimeError("Set ACC_ADMIN_PASSWORD (12+ characters) in .env first")
    if not cfg["key"]:
        raise RuntimeError("Set ACC_ENCRYPTION_KEY in .env first")
    Fernet(cfg["key"].encode())
    parsed = urlparse(cfg["origin"])
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise RuntimeError("Invalid ACC_BASE_URL")
    if parsed.scheme == "http" and parsed.hostname not in {"localhost", "127.0.0.1", "::1"}:
        raise RuntimeError("Remote connections must use HTTPS")
    if parsed.scheme == "https" and not cfg["cookie_secure"]:
        raise RuntimeError("Set ACC_SECURE_COOKIES=1 for HTTPS deployment")


@contextmanager
def db():
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DATA_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with db() as c:
        c.executescript("""
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS login_attempts (attempted_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS sessions (
           token_hash TEXT PRIMARY KEY, csrf TEXT NOT NULL, expires INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS oauth_states (
           state_hash TEXT PRIMARY KEY, provider TEXT NOT NULL,
           session_hash TEXT NOT NULL, expires INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS accounts (
           id TEXT PRIMARY KEY, provider TEXT NOT NULL, provider_user_id TEXT NOT NULL,
           display_name TEXT NOT NULL, email TEXT NOT NULL DEFAULT '',
           access_token TEXT NOT NULL, refresh_token TEXT NOT NULL DEFAULT '',
           scope TEXT NOT NULL DEFAULT '', expires_at INTEGER NOT NULL DEFAULT 0,
           connected_at INTEGER NOT NULL, UNIQUE(provider, provider_user_id)
        );
        CREATE TABLE IF NOT EXISTS tasks (
           id TEXT PRIMARY KEY, kind TEXT NOT NULL, account_id TEXT NOT NULL,
           title TEXT NOT NULL, payload TEXT NOT NULL,
           status TEXT NOT NULL, created_at INTEGER NOT NULL,
           decided_at INTEGER NOT NULL DEFAULT 0,
           result TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS events (
           id INTEGER PRIMARY KEY AUTOINCREMENT, happened_at INTEGER NOT NULL,
           kind TEXT NOT NULL, task_id TEXT NOT NULL DEFAULT '',
           description TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS flags (
           key TEXT PRIMARY KEY, value TEXT NOT NULL
        );
        INSERT OR IGNORE INTO flags(key,value) VALUES ('paused','0');
        """)



def login_throttled():
    with db() as c:
        c.execute("DELETE FROM login_attempts WHERE attempted_at < ?", (int(time.time()) - 900,))
        return c.execute("SELECT COUNT(*) AS n FROM login_attempts").fetchone()["n"] >= 8


def record_login_attempt(success):
    with db() as c:
        if success:
            c.execute("DELETE FROM login_attempts")
        else:
            c.execute("INSERT INTO login_attempts(attempted_at) VALUES (?)", (int(time.time()),))

def digest(token):
    return hashlib.sha256(token.encode()).hexdigest()


def new_session():
    token = secrets.token_urlsafe(32)
    csrf = secrets.token_urlsafe(24)
    with db() as c:
        c.execute("DELETE FROM sessions WHERE expires < ?", (int(time.time()),))
        c.execute("INSERT INTO sessions VALUES (?,?,?)", (digest(token), csrf, int(time.time()) + 60 * 60 * 24 * 7))
    return token, csrf


def get_session(token):
    if not token:
        return None
    with db() as c:
        return c.execute("SELECT * FROM sessions WHERE token_hash=? AND expires>?", (digest(token),int(time.time()))).fetchone()


def encrypt(token):
    if not token:
        return ""
    return Fernet(settings()["key"].encode()).encrypt(token.encode()).decode()


def decrypt(token):
    if not token:
        return ""
    return Fernet(settings()["key"].encode()).decrypt(token.encode()).decode()


def scrub_account(row):
    return {k: row[k] for k in ("id", "provider", "display_name", "email", "scope", "connected_at")}


def event(kind, description, task_id=""):
    with db() as c:
        c.execute("INSERT INTO events(happened_at,kind,task_id,description) VALUES (?,?,?,?)",
                  (int(time.time()), kind, task_id, description[:400]))


def is_paused():
    with db() as c:
        r=c.execute("SELECT value FROM flags WHERE key='paused'").fetchone()
        return r is not None and r["value"] == "1"


def set_paused(value):
    with db() as c:
        c.execute("UPDATE flags SET value=? WHERE key='paused'", ("1" if value else "0",))
    event("control", "Execution stopped" if value else "Execution enabled")


def validate_task(kind, payload):
    if kind not in ACCOUNT_ACTIONS:
        raise ValueError("Unsupported task type")
    if not isinstance(payload, dict):
        raise ValueError("Payload must be an object")
    if kind == "github_create_issue":
        owner=payload.get("owner", "")
        repo=payload.get("repo", "")
        title=payload.get("title", "")
        body=payload.get("body", "")
        if not GITHUB_REPO.fullmatch(owner) or not GITHUB_REPO.fullmatch(repo):
            raise ValueError("Invalid repository")
        if not isinstance(title,str) or not title.strip() or len(title) > 180:
            raise ValueError("Issue title must be 1–180 characters")
        if not isinstance(body,str) or len(body)>5000:
            raise ValueError("Issue body exceeds 5000 characters")
        if set(payload) - {"owner","repo","title","body"}:
            raise ValueError("Unexpected task arguments")
        return {"owner": owner, "repo": repo, "title": title.strip(), "body":body}
    raise ValueError("Unsupported task")


def safe_log(value):
    """Only explicit sanitized strings may enter the durable event stream."""
    return re.sub(r"(?i)(bearer\s+\S+|gh[pousr]_[A-Za-z0-9]+|sk-[A-Za-z0-9_-]+)", "[REDACTED]", str(value))[:400]
