"""One-time local setup; secrets never printed or committed."""
from pathlib import Path
from getpass import getpass
from cryptography.fernet import Fernet
import os
p=Path(__file__).resolve().parent/'.env'
if p.exists():
    raise SystemExit('.env already exists; refusing to overwrite it')
password=getpass('Choose a controller password (12+ characters): ')
if len(password)<12:
    raise SystemExit('Password must contain at least 12 characters')
# Use simple shell-safe quoting so no dotenv expansion or accidental newline.
if any(c in password for c in '\n\r"\\$'):
    raise SystemExit('Choose a password without line breaks, double quotes, backslashes or dollar signs')
text='ACC_ADMIN_PASSWORD="'+password+'"\nACC_ENCRYPTION_KEY="'+Fernet.generate_key().decode()+'"\nACC_BASE_URL="http://127.0.0.1:8787"\nACC_SECURE_COOKIES=0\n'
with p.open('x', encoding='utf8') as f: f.write(text)
try: os.chmod(p,0o600)
except OSError: pass
print('Created private .env. No accounts are linked yet. Run: python run.py')
