/* Account Command Center v0.1. No secrets/tokens are stored in browser storage. */
(() => {
'use strict';
const $ = id => document.getElementById(id);
const allowedProviders = [
  {id:'github',name:'GitHub',symbol:'GH',description:'Authorize a GitHub identity. Read repositories and propose issue creation; writes require approval.'},
  {id:'google',name:'Google',symbol:'G',description:'Authorize Google identity for read-only Drive metadata and Gmail message IDs.'},
  {id:'openai_api',name:'OpenAI API',symbol:'AI',description:'Optional AI planner on your private server. Separate from a ChatGPT subscription; usage can cost money.'},
  {id:'chatgpt',name:'ChatGPT',symbol:'✳',description:'Open a ChatGPT account as a shortcut. Consumer session automation is not an OAuth connection.'}
];
const state = {mode:'loading',csrf:'',providers:{},accounts:[],tasks:[],events:[],paused:false,shortcuts:load('acc_shortcuts',[]),drafts:load('acc_drafts',[]),logs:load('acc_logs',[]),localPaused:load('acc_paused',false)};
let toastTimer;
function load(k,def){try{const v=JSON.parse(localStorage.getItem(k));return v??def;}catch{return def;}}
function persist(k,v){localStorage.setItem(k,JSON.stringify(v));}
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=t=> t ? new Date(t*1000).toLocaleString():'—';
function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),4500);}
function modal(id,on){$(id).classList.toggle('hidden',!on);}
function details(title,body){const box=$('details-modal');box.querySelector('h2').textContent=title;$('details-content').textContent=body;modal('details-modal',true);}
function localEvent(kind,description){state.logs.unshift({id:Date.now(),kind,description,happened_at:Math.floor(Date.now()/1000)});state.logs=state.logs.slice(0,80);persist('acc_logs',state.logs);}
async function api(path,opts={}){
  const method=opts.method||'GET';const headers={...(opts.headers||{})};
  if(method!=='GET' && method!=='HEAD'){headers['Content-Type']='application/json';headers['X-CSRF-Token']=state.csrf;}
  const response=await fetch(path,{credentials:'same-origin',...opts,headers});
  let data={};try{data=await response.json();}catch{}
  if(!response.ok)throw new Error(typeof data.detail==='string'?data.detail:`Request failed (${response.status})`);
  return data;
}
async function boot(){
  try{
    const r=await fetch('/api/status',{cache:'no-store',signal:AbortSignal.timeout(4500)});
    if(!r.ok)throw new Error('No private server');
    const info=await r.json();if(!info.ok||info.mode!=='server')throw new Error('No private server');
    state.mode='server';state.providers=info.providers;
    try{await refresh();}catch(e){if(/Sign in first|401/i.test(e.message)){state.mode='locked';modal('login-modal',true);}else throw e;}
  }catch(e){
    if(state.mode==='loading'){
      state.mode='preview';state.paused=state.localPaused;state.tasks=state.drafts;state.events=state.logs;
      toast('Local planning mode: no authorized account backend connected');
    }else if(state.mode==='server'){toast(e.message);}
  }
  if(location.search.includes('oauth=')){
    const result=new URLSearchParams(location.search).get('oauth');
    toast(result==='connected'?'Account linked by OAuth':`OAuth: ${result}`);
    history.replaceState(null,'',location.pathname);
  }
  render();
  checkCF0();
}
async function refresh(){
  const data=await api('/api/bootstrap');state.csrf=data.csrf;state.accounts=data.accounts;state.tasks=data.tasks;state.events=data.events;state.paused=data.paused;
  state.mode='server';modal('login-modal',false);render();
}
function render(){
  const live=state.mode==='server';const preview=!live;
  $('mode-text').textContent=live?'PRIVATE SERVER CONNECTED · ACCOUNT WRITES REQUIRE APPROVAL':state.mode==='locked'?'OWNER SIGN-IN REQUIRED · ACCOUNTS LOCKED':'LOCAL PLANNING MODE · NO LIVE ACCOUNT ACCESS';
  $('side-state').textContent=live?'Private server online':state.mode==='locked'?'Controller locked':'Offline/local mode';
  $('stat-accounts').textContent=live?state.accounts.length:'0';
  $('stat-approvals').textContent=live?state.tasks.filter(t=>t.status==='pending_approval').length:'0';
  $('stat-completed').textContent=live?state.tasks.filter(t=>t.status==='completed').length:'0';
  $('control-state').textContent=state.paused?'STOPPED':'APPROVAL-GATED';
  $('gate-label').textContent=state.paused?'STOP ACTIVE':'APPROVAL-GATED';
  $('gate-label').style.color=state.paused?'#ff8e93':'#85edcc';
  $('gate-title').textContent=state.paused?'Controller execution stopped':'Actions require approval';
  $('gate-desc').textContent=state.paused?'This controller will reject execution requests until resumed. External schedules are not affected.':'No account action runs from an AI plan alone. Every supported write requires a deliberate owner action.';
  $('stop-btn').textContent=state.paused?'▶ Resume controller actions':'■ Stop controller actions';
  $('stop-btn').classList.toggle('resume',state.paused);
  $('goal-hint').textContent=state.providers.openai_api && live?'Optional API model may incur usage charges. Nothing executes from a plan.':'Local rules-based planning is available without AI billing.';
  renderIntegrations();renderAccounts();renderTasks();renderEvents();
}
function renderIntegrations(){
  const connected=p=>state.accounts.filter(a=>a.provider===p).length;
  $('overview-integrations').innerHTML=allowedProviders.map(p=>`<button class="integration-tile" data-go="accounts"><span class="provider-symbol">${esc(p.symbol)}</span><b>${esc(p.name)}</b><small>${connected(p.id)?`${connected(p.id)} authorized`:p.id==='openai_api'&&state.providers.openai_api?'API ready':p.id==='chatgpt'?'shortcut only':'Not linked'}</small></button>`).join('');
}
function renderAccounts(){
  const list=$('connected-list');
  list.innerHTML=state.accounts.length?state.accounts.map(a=>`<div class="connected-account"><span class="provider-symbol">${a.provider==='google'?'G':'GH'}</span><div><div class="account-name">${esc(a.display_name)}</div><div class="account-email">${esc(a.email||a.provider)}</div><div class="account-meta">AUTHORIZED · ${esc(a.provider.toUpperCase())}</div></div><div class="actions"><button class="minor-btn" data-inspect="${esc(a.id)}">Inspect</button>${a.provider==='google'?`<button class="minor-btn" data-gmail="${esc(a.id)}">Gmail count</button>`:''}<button class="minor-btn" data-unlink="${esc(a.id)}">Unlink</button></div></div>`).join(''):
   '<div class="empty-state">No OAuth-connected identities yet. Each service below needs its own authorized connection.</div>';
  $('provider-grid').innerHTML=allowedProviders.map(p=>{
    const active=state.mode==='server' && (p.id==='chatgpt'||state.providers[p.id]);
    const label=p.id==='chatgpt'?'Open ChatGPT':p.id==='openai_api'?(state.providers.openai_api?'API configured':'Setup required'):
    active?'Authorize account':'Server setup required';
    return `<div class="provider-card"><div class="row"><span class="provider-symbol">${esc(p.symbol)}</span><b>${esc(p.name)}</b></div><p>${esc(p.description)}</p><button class="secondary-btn" data-provider="${p.id}">${esc(label)}</button></div>`;
  }).join('');
  $('shortcuts').innerHTML=state.shortcuts.length?state.shortcuts.map((s,i)=>`<div class="shortcut"><a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.name)} ↗</a><small>SHORTCUT ONLY</small><button aria-label="Delete shortcut" data-shortcut-delete="${i}">×</button></div>`).join(''):'<p class="micro">No saved shortcuts.</p>';
}
function renderTasks(){
  $('task-account').innerHTML='<option value="">'+(state.mode==='server'?'Select an authorized GitHub identity':'Server required for real execution')+'</option>'+state.accounts.filter(a=>a.provider==='github').map(a=>`<option value="${esc(a.id)}">${esc(a.display_name)}</option>`).join('');
  $('task-list').innerHTML=state.tasks.length?state.tasks.map(t=>{
    const pending=t.status==='pending_approval';const proposal=t.status==='draft_local';
    return `<div class="task-card"><div class="task-top"><div><h3>${esc(t.title)}</h3><p>${esc(t.kind.replaceAll('_',' '))} · ${esc(fmt(t.created_at))}</p></div><span class="task-status ${esc(t.status)}">${esc(t.status.replaceAll('_',' ').toUpperCase())}</span></div>${t.payload?`<p class="micro">${esc(typeof t.payload==='string'?t.payload:JSON.stringify(t.payload))}</p>`:''}${t.result?`<p class="micro">${esc(t.result)}</p>`:''}${pending?`<div class="task-actions"><button class="primary-btn" data-execute="${esc(t.id)}" ${state.paused?'disabled':''}>Review & execute</button><button class="minor-btn" data-reject="${esc(t.id)}">Reject</button></div>`:proposal?'<p class="micro">Planning draft only. No account action is possible without a configured server.</p>':''}</div>`;
  }).join(''):'<div class="empty-state">No account actions have been proposed. This is an empty queue, not completed work.</div>';
}
function renderEvents(){
  $('activity-list').innerHTML=state.events.length?state.events.map(e=>`<div class="activity-card"><span class="event-icon">${e.kind==='execution'?'✓':e.kind==='control'?'■':'•'}</span><div><b>${esc(e.kind.replaceAll('_',' ').toUpperCase())}</b><p>${esc(e.description)}</p></div><time>${esc(fmt(e.happened_at))}</time></div>`).join(''):'<div class="empty-state">No activity recorded. The log is not evidence of account or HP activity unless genuine events exist.</div>';
}
function navigate(page){
  if(!['overview','accounts','tasks','activity'].includes(page))return;
  for(const el of document.querySelectorAll('.page'))el.classList.toggle('active',el.id===page);
  for(const b of document.querySelectorAll('[data-go]'))b.classList.toggle('active',b.dataset.go===page);
  $('page-title').textContent=({overview:'Command overview',accounts:'Account registry',tasks:'Task queue',activity:'Evidence log'})[page];
  history.replaceState(null,'','#'+page);
  window.scrollTo({top:0,behavior:'smooth'});
}
async function checkCF0(){
  $('cf0-title').textContent='Checking public source…';
  try{
    const paths=['https://raw.githubusercontent.com/whoiwts110217-creator/CF-0/main/docs/PUBLIC_CONTINUITY_STATE.json','https://raw.githubusercontent.com/whoiwts110217-creator/CF-0/main/relay/health/latest.json'];
    const [a,b]=await Promise.all(paths.map(url=>fetch(url,{cache:'no-store',signal:AbortSignal.timeout(9000)}).then(r=>{if(!r.ok)throw Error('Source unavailable');return r.json();})));
    const verified=a?.cf200?.verified, target=a?.cf200?.target;
    const hasCount=Number.isInteger(verified)&&Number.isInteger(target);
    $('cf0-title').textContent=hasCount?`${verified} / ${target} source work orders verified`:'CF-0 source retrieved';
    $('cf0-description').textContent=`HP public health: ${b?.collected_utc?'report timestamp '+b.collected_utc:'timestamp missing'}. Device identity, scheduler and unattended operations not independently established.`;
    $('cf0-meta').textContent=`Source: public main · dated ${a.as_of_date_et||'unknown'} · separate from live HP control`;
  }catch(e){
    $('cf0-title').textContent='Public CF-0 source unavailable';
    $('cf0-description').textContent='Cannot verify status right now. No HP or GitHub action was sent.';
    $('cf0-meta').textContent='Source access failed · no cached status claimed';
  }
}
function localPlan(goal){
  const terms=goal.toLowerCase();
  const steps=['LOCAL RULES-BASED PLAN (NOT AN AI RESPONSE; NO ACTIONS EXECUTED)','1. Identify which specific account owns the requested data or action.','2. Verify the account is actually OAuth-connected and has only the necessary scopes.'];
  if(/git|issue|repo|code/.test(terms))steps.push('3. Inspect relevant GitHub repository data; draft a GitHub issue only when appropriate.');
  else if(/mail|gmail|drive|google/.test(terms))steps.push('3. Read approved Google metadata without downloading private files or taking write actions.');
  else if(/chatgpt|gpt|conversation|continue/.test(terms))steps.push('3. Keep ChatGPT consumer session operations in the authorized browser/CF-0 bridge; this app does not control those sessions.');
  else steps.push('3. Produce a concrete task proposal with evidence requirements and minimum permissions.');
  steps.push('4. Require an explicit approval for any supported write. Record the provider-confirmed result or label it unknown.');
  return steps.join('\n');
}
async function plan(){
  const goal=$('goal-input').value.trim();if(goal.length<3){toast('Describe a goal first');return;}
  const box=$('plan-result');box.classList.remove('hidden');box.textContent='Preparing proposal…';
  if(state.mode==='server'&&state.providers.openai_api){
    if(!confirm('Send this goal to the separately billed OpenAI API for planning? No account task will execute.')){box.textContent='Planning canceled.';return;}
    try{const r=await api('/api/ai/plan',{method:'POST',body:JSON.stringify({goal})});box.textContent='AI-PROPOSED PLAN (NOT EXECUTED)\n\n'+r.plan;await refresh();return;}catch(e){toast(e.message);}
  }
  box.textContent=localPlan(goal);
  localEvent('plan','Local goal converted into a planning proposal (no execution)');if(state.mode!=='server'){state.events=state.logs;renderEvents();}
}
async function stop(){
  const next=!state.paused;
  if(state.mode==='server'){
    try{const r=await api('/api/control',{method:'POST',body:JSON.stringify({paused:next})});state.paused=r.paused;await refresh();toast(next?'This controller is stopped. Other schedules are unaffected.':'This controller may execute owner-approved actions again.');}catch(e){toast(e.message);}
  }else{state.paused=next;state.localPaused=next;persist('acc_paused',next);localEvent('control',next?'Local planning execution gate set to stop':'Local planning gate resumed');state.events=state.logs;render();toast('Local setting changed. No external service was affected.');}
}
async function connect(provider){
  if(provider==='chatgpt'){window.open('https://chatgpt.com/','_blank','noopener,noreferrer');return;}
  if(provider==='openai_api'){details('Optional AI planning','Set OPENAI_API_KEY privately on the server and restart. This uses the separate developer API, not your ChatGPT subscription. The app never imports a ChatGPT login.');return;}
  if(state.mode!=='server'||!state.providers[provider]){details('OAuth setup required',`To authorize ${provider}, run the private server over HTTPS with a provider OAuth client ID and secret. Register the matching /api/oauth/${provider}/callback URL at the provider. The app never asks you to paste a service password.`);return;}
  location.assign('/api/oauth/'+encodeURIComponent(provider)+'/start');
}
async function inspectAccount(id,mode='inspect'){
  try{const result=await api(`/api/accounts/${encodeURIComponent(id)}/${mode==='gmail'?'gmail':'inspect'}`);
    const msg=mode==='gmail'?`Gmail message IDs returned: ${result.message_count_returned}. Only metadata/listing; no messages opened.`:
      result.kind==='github_repos'?`Latest repositories:\n${(result.items||[]).map(x=>`${x.name}${x.private?' (private)':''}`).join('\n')}`:`Latest Drive file names:\n${(result.items||[]).map(x=>x.name).join('\n')}`;
    details('Read-only account inspection',msg||'No results returned.');
  }catch(e){toast(e.message);}
}
async function unlinkAccount(id){
  if(!confirm('Unlink this account from the controller? Provider-side authorization must also be revoked at the provider.'))return;
  try{const r=await api(`/api/accounts/${encodeURIComponent(id)}`,{method:'DELETE'});await refresh();toast(r.note);}catch(e){toast(e.message);}
}
function addShortcut(){
  const name=$('shortcut-name').value.trim(),raw=$('shortcut-url').value.trim();
  let url;try{url=new URL(raw);}catch{toast('Enter a complete https:// account URL');return;}
  if(!name||name.length>60||url.protocol!=='https:'||url.username||url.password){toast('Use a name and a safe https:// URL without login credentials');return;}
  if(state.shortcuts.length>=30){toast('30 shortcut limit');return;}
  state.shortcuts.push({name,url:url.href});persist('acc_shortcuts',state.shortcuts);
  $('shortcut-name').value='';$('shortcut-url').value='';renderAccounts();toast('Saved as a shortcut only — not an authorized connection');
}
async function queueTask(e){
  e.preventDefault();const account_id=$('task-account').value;
  const payload={owner:$('task-owner').value.trim(),repo:$('task-repo').value.trim(),title:$('task-title').value.trim(),body:$('task-body').value};
  if(!/^[\w.-]{1,100}$/.test(payload.owner)||!/^[\w.-]{1,100}$/.test(payload.repo)||!payload.title){toast('Check repository owner, repository and issue title');return;}
  if(state.mode!=='server'){
    const task={id:'local-'+Date.now(),kind:'github_create_issue',title:'Draft GitHub issue: '+payload.title,payload,status:'draft_local',created_at:Math.floor(Date.now()/1000)};
    state.drafts.unshift(task);state.drafts=state.drafts.slice(0,50);persist('acc_drafts',state.drafts);state.tasks=state.drafts;
    localEvent('proposal','Saved local draft only; requires private server and authorized account');state.events=state.logs;render();toast('Saved a local draft. It cannot execute.');return;
  }
  if(!account_id){toast('Connect and select a GitHub account first');return;}
  try{await api('/api/tasks',{method:'POST',body:JSON.stringify({kind:'github_create_issue',account_id,payload})});await refresh();toast('Proposed. Nothing published. Review before execution.');}
  catch(e){toast(e.message);}
}
async function actTask(id,action){
  const task=state.tasks.find(t=>t.id===id);if(!task)return;
  if(action==='execute'){
    if(state.paused){toast('Execution stop is active');return;}
    let p;try{p=typeof task.payload==='string'?JSON.parse(task.payload):task.payload;}catch{toast('Cannot verify task arguments');return;}
    if(!confirm(`EXECUTE THIS REAL ACCOUNT WRITE?\n\nAccount: ${task.account_id}\nRepository: ${p.owner}/${p.repo}\nIssue: ${p.title}\n\nThis creates a public/private repository issue with the authorized GitHub identity. No automatic retries.`))return;
  }else if(!confirm('Reject this proposed task?'))return;
  try{const r=await api(`/api/tasks/${encodeURIComponent(id)}/${action==='execute'?'execute':'reject'}`,{method:'POST',body:'{}'});await refresh();toast(action==='execute'?`Provider result: ${r.status}`:'Task rejected');}
  catch(e){toast(e.message);}
}
function handleClicks(e){
  const b=e.target.closest('button');if(!b)return;
  if(b.dataset.go)navigate(b.dataset.go);
  if(b.dataset.provider)connect(b.dataset.provider);
  if(b.dataset.inspect)inspectAccount(b.dataset.inspect);
  if(b.dataset.gmail)inspectAccount(b.dataset.gmail,'gmail');
  if(b.dataset.unlink)unlinkAccount(b.dataset.unlink);
  if(b.dataset.execute)actTask(b.dataset.execute,'execute');
  if(b.dataset.reject)actTask(b.dataset.reject,'reject');
  if(b.dataset.shortcutDelete!==undefined){state.shortcuts.splice(Number(b.dataset.shortcutDelete),1);persist('acc_shortcuts',state.shortcuts);renderAccounts();}
}
function wire(){
  document.addEventListener('click',handleClicks);
  $('stop-btn').addEventListener('click',stop);
  $('lock').addEventListener('click',async()=>{if(state.mode==='server'){if(!confirm('Lock and sign out of the controller?'))return;try{await api('/api/logout',{method:'POST',body:'{}'});state.mode='locked';state.accounts=[];state.tasks=[];state.events=[];state.csrf='';render();modal('login-modal',true);}catch(e){toast(e.message);}}else details('No server session','Local planning mode has no authenticated server session to lock.');});
  $('plan-btn').addEventListener('click',plan);
  $('cf0-refresh').addEventListener('click',checkCF0);
  $('refresh').addEventListener('click',async()=>{if(state.mode==='server'){try{await refresh();}catch(e){toast(e.message);}}else render();checkCF0();toast('Status refreshed');});
  $('banner-help').addEventListener('click',()=>details('Account permissions',state.mode==='server'?'The private server is online. Accounts only become authorized through provider OAuth. GitHub issue creation is a real write and always requires a separate owner click. Emergency stop blocks only this app.':'This is a local planning interface. You may save URL shortcuts, draft tasks, and inspect public CF-0 status, but no external accounts are connected or controlled. Deploy the included private server and configure OAuth to enable real account actions.'));
  $('details-ok').addEventListener('click',()=>modal('details-modal',false));$('close-details').addEventListener('click',()=>modal('details-modal',false));
  $('shortcut-save').addEventListener('click',addShortcut);
  $('task-form').addEventListener('submit',queueTask);
  $('login-form').addEventListener('submit',async e=>{e.preventDefault();try{const r=await api('/api/login',{method:'POST',body:JSON.stringify({password:$('login-password').value})});state.csrf=r.csrf;$('login-password').value='';await refresh();toast('Controller unlocked');}catch(err){toast(err.message);}});
  window.addEventListener('hashchange',()=>{let p=location.hash.slice(1);if(['overview','accounts','tasks','activity'].includes(p))navigate(p);});
}
wire();
const initial=location.hash.slice(1);if(['overview','accounts','tasks','activity'].includes(initial))navigate(initial);
boot();
if('serviceWorker' in navigator && (location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1')){
  window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
}
})();
