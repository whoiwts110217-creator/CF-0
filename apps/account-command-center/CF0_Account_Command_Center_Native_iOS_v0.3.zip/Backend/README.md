# Caveman Focus — Account Command Center v0.1 (iPhone-first)

**Status: a source-tested prototype, not a deployed or App Store-signed app.** This package contains a complete responsive PWA shell, an optional self-hosted private OAuth broker/API, tests, and Windows starter scripts. It keeps the existing CF-0 Mission Control untouched. The iPhone version is installed from Safari using **Share → Add to Home Screen** *after* the web app has been hosted over HTTPS.

## What actually works

- **iPhone touch-first screen** with Overview, Accounts, Tasks, Activity, dark/cyan theme, installable PWA manifest/icons, offline shell, mobile bottom navigation.
- **Without the private server:** local no-secret workspace shortcuts; local draft tasks; local rules-based planning; emergency-stop state that affects only that local interface; read-only **public** CF-0 status (`docs/PUBLIC_CONTINUITY_STATE.json` and `relay/health/latest.json`) when network permits. No actual account is connected in this mode.
- **With the private server and provider OAuth configured:** password-protected owner session, multiple OAuth identities per provider, encrypted OAuth tokens in SQLite, GitHub repository listing, Google Drive file-name listing, Gmail message-ID listing, CSRF-guarded task proposal/rejection, explicit one-time GitHub issue creation and provider-confirmed completion receipts, local app stop/resume, evidence log, session lock/logout.
- **Optional OpenAI developer API:** goal → plan, with explicit confirmation before submitting a goal. The AI plans but **does not execute** a task. A ChatGPT subscription and ChatGPT consumer account are **not** OAuth-connected to this controller, and OpenAI API billing is separate.
- **Single-owner default.** No account passwords entered into the app; sign-in to Google/GitHub occurs at their official OAuth websites.

## Quick start on a Windows computer

Install Python 3.11 or newer. Extract the ZIP, open the extracted folder, then double-click `start_windows.bat` (or run the following from a terminal):

```powershell
py -m pip install -r requirements.txt
py setup_local.py
py run.py
```

`setup_local.py` privately asks for a 12+-character controller password and generates a Fernet encryption key. It creates a local `.env` file that **must never be published**. Open `http://127.0.0.1:8787` on that same PC. The web app initially has no account OAuth credentials and cannot control your existing ChatGPT session.

**Important: `127.0.0.1` is the PC itself. It is not an iPhone-accessible address.** To reach the private account backend from an iPhone, the owner must deploy it to an authorized HTTPS origin, or configure a secure, authenticated HTTPS reverse proxy or tunnel. Update `ACC_BASE_URL` and set `ACC_SECURE_COOKIES=1` before remote deployment. Do not expose a plain HTTP server or private SQLite database on a public network. This package does not silently deploy a public service.

## Connect accounts using OAuth

The server will say **Setup required** until you register a provider OAuth application and supply the corresponding credentials in the server's private `.env` file.

| Connector | Backend env vars | OAuth callback URL registered at provider | Supported scope | Current actions |
| --- | --- | --- | --- | --- |
| GitHub OAuth App | `GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET` | `https://YOUR-DOMAIN/api/oauth/github/callback` | `read:user public_repo` | Read repositories; create an issue only after per-task owner approval |
| Google OAuth client (Web application) | `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | `https://YOUR-DOMAIN/api/oauth/google/callback` | `openid email profile`, Gmail read-only, Drive metadata read-only | List Gmail IDs / Drive file names, no sending or editing |
| OpenAI developer API (optional) | `OPENAI_API_KEY` | None | API key configured on private server | Produce bounded task proposals only; never writes to accounts |
| ChatGPT consumer / other GPT accounts | None in v0.1 | None | No direct session rights | Save/open shortcuts; no private chat history or automatic `continue` |

OAuth grants can be revoked directly in the GitHub/Google account's connected-app security settings. `Unlink` deletes the stored local credential, but cannot guarantee upstream revocation. Grant only the scopes you need. The GitHub OAuth App model's `public_repo` is broader than a single repo; a future GitHub App with per-repo installation would be preferable. Google sensitive scopes may require app verification or test-user setup.

**A link is not a connection:** the shortcut registry can hold labeled URLs for multiple ChatGPT accounts, Discord, Cash App and other sites, but it never claims to read or operate them. Never paste passwords, OAuth tokens, recovery codes, payment credentials, or private exports in shortcuts, local drafts, or GitHub.

## iPhone installation

1. Host the `web/` app and `server/` API at **one private HTTPS origin**, with `/api/*` routed to the Python server. The server already serves both together; a reverse proxy can terminate HTTPS. Avoid public static GitHub Pages hosting for the private backend.
2. Open the HTTPS address **in Safari on iPhone**.
3. Tap **Share → Add to Home Screen** and ensure **Open as Web App** is on; tap Add.
4. Sign into the controller with its private owner password. Tap Accounts and use provider OAuth where configured.

The browser/offline PWA cannot run scheduled background jobs while the phone is asleep. This v0.1 backend does **not** start an autonomous scheduler. It performs explicitly requested actions when the owner presses Execute. Existing CF-0 scheduled tasks remain separate.

## Data and trust boundaries

- Tokens are encrypted at rest with Fernet on the private server, **not** in `localStorage`, and are never returned by `/api/bootstrap`. Only owner-local shortcut URLs and non-secret draft metadata are stored in the browser.
- The private server requires a non-default 12+ character password; signed HttpOnly cookie; HTTPS+Secure cookie for remote deployment; CSRF token for writes; 8-failed-logins/15-minute global rate limit; 10-minute OAuth states bound to the owner session; encrypted access/refresh tokens.
- Any GitHub write requires a manually created, allowlisted proposal plus an owner click on **Review & execute**; SQL state transition guards prevent duplicate submission. A timeout after a write produces `outcome_unknown`, never an automatic retry. The controller is not an unrestricted browser or shell executor.
- The emergency stop blocks **only this app's execution endpoint**. It cannot stop external CF-0 Actions, ChatGPT automations, active provider sessions, or physical HP workers.
- Public CF-0 JSON is only source evidence, not authenticated physical HP identity or verified unattended execution. This app never sends commands into the existing public HP relay.
- The controller is a personal prototype. Before production use, add security review, managed encrypted backups, account grant inventory, improved per-connector scopes, network/reverse-proxy hardening, monitoring, and actual iPhone/OAuth acceptance tests.

## Continuity and provenance

The app was built after reading the current `main` public project instructions and capability boundaries. It **does not replace** the existing Mission Control, private archives, AUTO-08 single-tab runner, or CF-200 verified-task ledger. It links to the read-only Mission Control and reads the public dated state.

Sources inspected on November 9, 2026:

- `automation_200/MASTER_OPERATOR_PROMPT.md` — blob SHA `22ae58c3bc1a7513ef45e4c8267ea011a56bb357`
- `automation_200/MASTER_CONTINUITY_PROMPT.md` — blob SHA `6d0cf4ac809172d0525de288d87a340d1f01537c`
- `automation_200/WORK_COPY_PASTE_AUTOMATION_PROMPT.md` — blob SHA `150c6629ba1496c2b05d9f4afb31929ad142357e`
- `automation_200/OWNER_CAPABILITY_CONTRACT.json` — blob SHA `a84bc07afd34d21fe03342593696220b9a3fa35f`
- `docs/PUBLIC_CONTINUITY_STATE.json` — blob SHA `2ea04e4b6e955dc5ca2779844e76d61e6466c80f`
- `relay/health/latest.json` — blob SHA `da5265dcad8a8ac463e84325bbd99f9740569a7c`

The private integrated master record was not opened for this separate source package; do not treat this app as a complete recovery or as an approved update to the public repository. New source in this package should receive an explicit CF-0 project identity, owner review, and a reversible handoff before integration.

## Test locally

```bash
python -m pytest -q tests/test_server.py
node --check web/app.js
node --check web/sw.js
```

Tests use synthetic tokens and mocked GitHub success. They prove only local server behavior. No live Google/GitHub account or owner iPhone is connected by these tests.
