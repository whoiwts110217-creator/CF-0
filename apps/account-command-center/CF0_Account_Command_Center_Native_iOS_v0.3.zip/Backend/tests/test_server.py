"""Tests: secure-by-default runtime, action gating, idempotence, and honest state labels."""
import importlib
import json
import time
from pathlib import Path
import httpx
import pytest
from cryptography.fernet import Fernet
from fastapi.testclient import TestClient

from server import core
server = importlib.import_module('server.app')


@pytest.fixture
def client(monkeypatch, tmp_path):
    monkeypatch.setenv('ACC_ADMIN_PASSWORD', 'a-strong-unique-password')
    monkeypatch.setenv('ACC_ENCRYPTION_KEY', Fernet.generate_key().decode())
    monkeypatch.setenv('ACC_BASE_URL', 'http://127.0.0.1:8787')
    monkeypatch.setenv('ACC_SECURE_COOKIES','0')
    monkeypatch.delenv('GITHUB_CLIENT_ID',raising=False)
    monkeypatch.delenv('GITHUB_CLIENT_SECRET',raising=False)
    monkeypatch.delenv('OPENAI_API_KEY',raising=False)
    monkeypatch.setattr(core,'DATA_PATH',tmp_path/'private'/'acc.sqlite3')
    with TestClient(server.app,base_url='http://127.0.0.1:8787') as c:
        yield c


def login(c):
    assert c.post('/api/login',json={'password':'a-strong-unique-password'}).status_code==200
    return c.get('/api/bootstrap').json()['csrf']


def headers(csrf):
    return {'x-csrf-token':csrf}


def task_data():
    return {'kind':'github_create_issue','account_id':'g1','payload':{'owner':'example','repo':'demo','title':'Test issue','body':'Proof needs to be checked'}}


def test_boot_requires_auth(client):
    assert client.get('/api/bootstrap').status_code==401
    assert client.get('/api/status').json()['providers']['openai_api'] is False
    assert client.get('/api/oauth/github/start').status_code==401


def test_login_bad_password_and_csrf(client):
    assert client.post('/api/login',json={'password':'wrong'}).status_code==401
    csrf=login(client)
    assert client.post('/api/control',json={'paused':True}).status_code==403
    assert client.post('/api/control',json={'paused':True},headers=headers(csrf)).status_code==200
    assert client.get('/api/bootstrap').json()['paused'] is True


def test_rate_limit(client):
    for _ in range(8):
        assert client.post('/api/login',json={'password':'wrong'}).status_code==401
    assert client.post('/api/login',json={'password':'a-strong-unique-password'}).status_code==429


def test_validation_blocks_untrusted_actions():
    with pytest.raises(ValueError):core.validate_task('run_shell',{'command':'rm -rf /'})
    with pytest.raises(ValueError):core.validate_task('github_create_issue',{'owner':'a/b','repo':'r','title':'test','body':''})
    with pytest.raises(ValueError):core.validate_task('github_create_issue',{'owner':'a','repo':'r','title':'x','body':'','token':'unsafe'})
    assert core.validate_task('github_create_issue',{'owner':'a','repo':'r','title':'x','body':''})['owner']=='a'


def test_queued_write_stop_and_rejection(client):
    csrf=login(client)
    with core.db() as c:
        c.execute('''INSERT INTO accounts(id,provider,provider_user_id,display_name,email,access_token,refresh_token,scope,expires_at,connected_at)
         VALUES(?,?,?,?,?,?,?,?,?,?)''',('g1','github','101','test-gh','',core.encrypt('fake-test-github-token'),'','public_repo',0,int(time.time())))
    assert client.post('/api/tasks',json=task_data()).status_code==403
    proposed=client.post('/api/tasks',json=task_data(),headers=headers(csrf))
    assert proposed.status_code==200
    task_id=proposed.json()['id']
    bootstrap=client.get('/api/bootstrap').json()
    assert bootstrap['tasks'][0]['status']=='pending_approval'
    assert bootstrap['accounts'][0]['display_name']=='test-gh'
    assert 'fake-test-github-token' not in json.dumps(bootstrap)
    assert client.post('/api/control',json={'paused':True},headers=headers(csrf)).json()['paused'] is True
    assert client.post('/api/tasks/'+task_id+'/execute',headers=headers(csrf)).status_code==423
    assert client.post('/api/tasks/'+task_id+'/reject',headers=headers(csrf)).status_code==200
    assert client.post('/api/tasks/'+task_id+'/reject',headers=headers(csrf)).status_code==409
    assert client.get('/api/bootstrap').json()['tasks'][0]['status']=='rejected'


def test_execute_once_and_no_duplicate(monkeypatch, client):
    csrf=login(client)
    with core.db() as c:
        c.execute('''INSERT INTO accounts(id,provider,provider_user_id,display_name,email,access_token,refresh_token,scope,expires_at,connected_at)
         VALUES(?,?,?,?,?,?,?,?,?,?)''',('g1','github','101','test-gh','',core.encrypt('fake-test-github-token'),'','public_repo',0,int(time.time())))
    task_id=client.post('/api/tasks',json=task_data(),headers=headers(csrf)).json()['id']
    calls=[]
    def reply(req):
        calls.append(req)
        assert req.url.path=='/repos/example/demo/issues'
        assert req.headers.get('Authorization')=='Bearer fake-test-github-token'
        return httpx.Response(201,json={'html_url':'https://github.com/example/demo/issues/42'})
    transport=httpx.MockTransport(reply)
    original=httpx.AsyncClient
    monkeypatch.setattr(server.httpx,'AsyncClient',lambda **kwargs:original(transport=transport,**kwargs))
    first=client.post('/api/tasks/'+task_id+'/execute',headers=headers(csrf))
    assert first.status_code==200 and first.json()['status']=='completed'
    assert len(calls)==1
    assert client.post('/api/tasks/'+task_id+'/execute',headers=headers(csrf)).status_code==409
    assert len(calls)==1
    assert client.get('/api/bootstrap').json()['tasks'][0]['result']=='https://github.com/example/demo/issues/42'


def test_oauth_requires_provider_config(client):
    login(client)
    assert client.get('/api/oauth/github/start',follow_redirects=False).status_code==409


def test_no_default_credentials(monkeypatch):
    monkeypatch.delenv('ACC_ADMIN_PASSWORD',raising=False)
    monkeypatch.delenv('ACC_ENCRYPTION_KEY',raising=False)
    with pytest.raises(RuntimeError):core.startup_guard(core.settings())


def test_log_redaction():
    assert 'ghp_' not in core.safe_log('Bearer ghp_myrealtesttoken')
