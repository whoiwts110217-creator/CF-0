# Account Command Center — v0.1 build receipt

**Artifact:** independent installable iPhone-first PWA and private OAuth/task broker package.
**Repository changes:** NONE. Existing CF-0 main and Mission Control unchanged.
**Account connection state:** NONE; no OAuth app IDs or tokens configured.
**Tested:** Python API tests (synthetic credentials + mocked provider result), JavaScript syntax, HTML/CSS mobile layout inspection.
**Not verified:** live provider OAuth redirect/callback, real GitHub issue creation, real Google listing, real OpenAI API output, remote hosting, physical iPhone Home Screen installation, unattended automation, multi-account ChatGPT session control, HP task execution.
**Priority:** P0 account-control architecture + permission gates; P1 explicit owner approval.
**Owner setup:** install/deploy over private HTTPS and register individual OAuth apps. No credentials should be supplied in chat or public GitHub.
**Compatibility:** Python backend on Windows; frontend is a standards-based iOS Safari web app, not an `.ipa` or signed native App Store binary.
**Retention:** `.env` and `private/` are ignored by Git. OAuth tokens encrypted via Fernet; local drafts/URL shortcuts not encrypted on the iPhone browser.
**Follow-on:** provider app registration, per-repository GitHub App scopes, honest account health, authenticated CF-0 private bridge (if explicitly approved), background worker only after real hosting and execution receipts.
